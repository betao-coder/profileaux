package com.example.profile_aux

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
